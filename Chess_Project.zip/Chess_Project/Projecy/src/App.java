import javafx.application.Application;
import javafx.stage.Stage;
import com.example.engine.board.Board;
import com.example.engine.board.Tile;
import com.example.engine.pieces.Piece;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

public class App extends Application{
    private final int BOARD_SIZE = 8;
    private final int TILE_SIZE = 80;
    private Button[][] boardButtons;
    //private Button button;
    private Tile fromTile = null;
    private Tile destinationTile = null;
    private Piece movedPiece = null;
    int[] TileId = new int[65];
    int tileCount = 0;

    Board board = Board.createStandardBoard();
    GridPane chessboard = new GridPane();
    ChessGame game;
    public static void main(String[] args) throws Exception {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        game = new ChessGame();

        chessboard = createBoardGUI();
        setBoardPieces(board);

        Scene scene = new Scene(chessboard, 800, 800);
        primaryStage.setTitle("Very Bad Chess");
        primaryStage.getIcons().add(new Image("C:\\Users\\AHMED\\Desktop\\Chess_Project\\Projecy\\src\\icon.png"));
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    private GridPane createBoardGUI() {
        GridPane chessboard = new GridPane();
        chessboard.setAlignment(Pos.CENTER);
        chessboard.setHgap(1);
        chessboard.setVgap(1);

        boardButtons = new Button[BOARD_SIZE][BOARD_SIZE];
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                Button tileButton = new Button();
                tileButton.setPrefSize(TILE_SIZE, TILE_SIZE);
                tileButton.setStyle("-fx-background-color: " + ((row + col) % 2 == 0 ? "white" : "gray"));
                int finalRow = row;
                int finalCol = col;
                tileButton.setOnMouseClicked(event -> handleTileClicked(finalRow, finalCol, event));
                boardButtons[row][col] = tileButton;
                chessboard.add(tileButton, col, row);
            }
        }
        return chessboard;
    }

    public void setBoardPieces(Board board) {
        tileCount = 0;
        ImageView pieceIcon;
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                Tile tile = game.getBoard().getTile(tileCount);
                pieceIcon = null;
                if (tile.isTileOccupied()) {
                    pieceIcon = tile.getPiece().getPieceIcon();
                }
                tileCount++;
                boardButtons[i][j].setGraphic(pieceIcon);
            }
        }
    }

    private void handleTileClicked(int row, int col, MouseEvent event) {
        if (event.getButton() == MouseButton.SECONDARY) {
            fromTile = game.getBoard().getTile(getTileId(row, col));
            System.out.println("\nfromTile ID: =========> " + fromTile.getTileCoordinate());
            movedPiece = fromTile.getPiece();

            if (movedPiece == null) {
                System.out.println("No piece is selected");
                fromTile = null;
            }
            else {
                System.out.println(movedPiece.toString() + " is Selected");
            }
        }

        else if (event.getButton() == MouseButton.PRIMARY) {
            if (movedPiece != null) {
                destinationTile = game.getBoard().getTile(getTileId(row, col));
                System.out.println("\nDestinationTile ID: =========> " + destinationTile.getTileCoordinate());

                boolean moveSuccess = game.makeMove(fromTile, destinationTile);
                if (moveSuccess) {
                    System.out.println(movedPiece.toString() + " has moved");
                    setBoardPieces(game.getBoard());
                    if (game.isGameOver()) {
                        /*TODO handle game over event*/
                        //displayGameOver();
                    }
                    fromTile = null;
                }
            }
        }
    }



    //convert rows and columns into a single number that represents TileId
    private int getTileId(int row, int col) {
        int tileId = -1;
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                ++tileId;
                if (i == row && j == col) {
                    return tileId;
                }
            }
        }
        return tileId;
    }
}
